package com.boardhub.chess.dataClasses;

import com.boardhub.R;
import com.boardhub.chess.pieces.Bishop;
import com.boardhub.chess.pieces.ChessPiece;
import com.boardhub.chess.pieces.King;
import com.boardhub.chess.pieces.Knight;
import com.boardhub.chess.pieces.Pawn;
import com.boardhub.chess.pieces.Queen;
import com.boardhub.chess.pieces.Rook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public interface ChessLogic {
    interface Constants{
        int classicModeDuration = 10*60*1000;
        int blitzModeDuration = 3*60*1000;
        int bulletModeDuration = 60*1000;

        int blackPawnIcon = R.drawable.chess_piece_black_pawn;
        int blackRookIcon = R.drawable.chess_piece_black_rook;
        int blackKnightIcon = R.drawable.chess_piece_black_knight;
        int blackBishopIcon = R.drawable.chess_piece_black_bishop;
        int blackQueenIcon = R.drawable.chess_piece_black_queen;
        int blackKingIcon = R.drawable.chess_piece_black_king;

        int whitePawnIcon = R.drawable.chess_piece_white_pawn;
        int whiteRookIcon = R.drawable.chess_piece_white_rook;
        int whiteKnightIcon = R.drawable.chess_piece_white_knight;
        int whiteBishopIcon = R.drawable.chess_piece_white_bishop;
        int whiteQueenIcon = R.drawable.chess_piece_white_queen;
        int whiteKingIcon = R.drawable.chess_piece_white_king;

        Character blackPawnText = '♟';
        Character blackRookText = '♜';
        Character blackKnightText = '♞';
        Character blackBishopText = '♝';
        Character blackQueenText = '♛';
        Character blackKingText = '♚';

        Character whitePawnText = '♙';
        Character whiteRookText = '♖';
        Character whiteKnightText = '♘';
        Character whiteBishopText = '♗';
        Character whiteQueenText = '♕';
        Character whiteKingText = '♔';

        int[][] rookDirections = new int[][]{
                {1, 0}, {-1, 0}, {1, 0}, {-1, 0}};
        int[][] bishopDirections = new int[][]{
                {1, 1}, {-1, 1}, {1, -1}, {-1, -1}};
        int[][] queenDirections = new int[][]{
                {1, 0}, {-1, 0}, {0, 1}, {0, -1},
                {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        int[][] knightDirections = new int[][]{
                {1, 2}, {1, -2}, {-1, 2}, {-1, -2},
                {2, 1}, {2, -1}, {-2, 1}, {-2, -1}};
        int[][] kingDirections = new int[][]{
                {1, 1}, {1, -1}, {-1, 1}, {-1, -1},
                {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    }

    static ArrayList<ChessMove> FindMovesByBFS(
            ChessPiece piece, int[][] directions){
        ArrayList<ChessMove> possibleMoves = new ArrayList<ChessMove>();
        ChessGame board = piece.GetPlayer().GetGame();

        for (int[] dir : directions) {
            int nextX = piece.GetXPos() + dir[0];
            int nextY = piece.GetYPos() + dir[1];

            while (IsPositionInBoard(nextX, nextY)) {
                ChessPiece pieceAtSquare = board.GetPieceAt(nextX, nextY);

                if (pieceAtSquare == null || piece.isDifferentColor(pieceAtSquare)) {
                    ChessMove move = new ChessMove(piece, pieceAtSquare, nextX, nextY);
                    if (IsValidMove(move)) possibleMoves.add(move);
                    if (pieceAtSquare != null){
                        break;
                    }
                }
                else {
                    break;
                }
                nextX += dir[0];
                nextY += dir[1];
            }
        }

        return possibleMoves;
    }

    static ArrayList<ChessMove> FindMovesByLocations(
            ChessPiece piece, int[][] directions){
        ArrayList<ChessMove> possibleMoves = new ArrayList<ChessMove>();

        ChessGame board = piece.GetPlayer().GetGame();

        for (int[] dir : directions) {
            int nextX = piece.GetXPos() + dir[0];
            int nextY = piece.GetYPos() + dir[1];

            if (nextX >= 0 && nextX < 8 && nextY >= 0 && nextY < 8) {
                ChessPiece pieceAtSquare = board.GetPieceAt(nextX, nextY);

                if (pieceAtSquare == null || piece.isDifferentColor(pieceAtSquare)) {
                    ChessMove move = new ChessMove(piece, pieceAtSquare, nextX, nextY);
                    if (IsValidMove(move)) possibleMoves.add(move);
                }
            }
        }

        return possibleMoves;
    }

    static boolean IsPositionInBoard(int xPos, int yPos){
        return xPos >= 0 && xPos < 8 && yPos >= 0 && yPos < 8;
    }

    // Checks and Board Validations

    static boolean IsValidMove(ChessMove move){
        ChessPiece movedPiece = move.movedPiece;
        ChessPiece capturedPiece = move.capturedPiece;
        int targetX = move.targetX;
        int targetY = move.targetY;

        ChessGame game = movedPiece.GetPlayer().GetGame();
        boolean isWhiteTurn = game.GetIsWhiteTurn();
        int initialX = movedPiece.GetXPos();
        int initialY = movedPiece.GetYPos();

        movedPiece.MoveTo(targetX, targetY);

        King king = isWhiteTurn ? game.GetWhitePlayer().GetKing() : game.GetBlackPlayer().GetKing();
        MockPiece[][] duplicate = DuplicateBoard(game);
        int kingX = king.GetXPos();
        int kingY = king.GetYPos();

        boolean inCheck = false;

        // 1. Check Sliding Pieces (Rooks, Bishops, Queens)
        for (int[] d : Constants.queenDirections) {
            for (int i = 1; i < 8; i++) {
                int checkX = kingX + (d[0] * i);
                int checkY = kingY + (d[1] * i);

                if (!IsPositionInBoard(checkX, checkY)) break;
                MockPiece p = duplicate[checkX][checkY];

                if (p != null) {
                    if (p.isWhite != isWhiteTurn) {
                        boolean isOrthogonal = (d[0] == 0 || d[1] == 0);
                        // Type 2=Rook, 4=Bishop, 5=Queen
                        if (p.type == 5 ||
                                (isOrthogonal && p.type == 2) ||
                                (!isOrthogonal && p.type == 4)) {
                            inCheck = true;
                        }
                    }
                    break; // Blocked by any piece
                }
            }
            if (inCheck) break;
        }

        // 2. Check Knights (Type 3)
        for (int[] m : Constants.knightDirections) {
            int nx = kingX + m[0], ny = kingY + m[1];
            if (nx >= 0 && nx <= 7 && ny >= 0 && ny <= 7) {
                MockPiece p = duplicate[nx][ny];
                if (p != null && p.isWhite != isWhiteTurn && p.type == 3) inCheck = true;
            }
        }

        // 3. Check Pawns (Type 1)
        // White king is hit by black pawns coming from 'above' (relative to Y direction)
        int pawnDir = isWhiteTurn ? 1 : -1;
        int[][] pawnThreats = {{1, pawnDir}, {-1, pawnDir}};
        for (int[] pt : pawnThreats) {
            int px = kingX + pt[0];
            int py = kingY + pt[1];
            if (IsPositionInBoard(px, py)) {
                MockPiece p = duplicate[px][py];
                if (p != null && p.isWhite != isWhiteTurn && p.type == 1)
                    inCheck = true;
            }
        }

        // 4. Check Enemy King (Type 6) - to prevent kings from standing next to each other
        for (int[] d : Constants.kingDirections) {
            int kx = kingX + d[0];
            int ky = kingY + d[1];
            if (IsPositionInBoard(kx, ky)) {
                MockPiece p = duplicate[kx][ky];
                if (p != null && p.isWhite != isWhiteTurn && p.type == 6)
                    inCheck = true;
            }
        }

        movedPiece.MoveTo(initialX, initialY);
        if (capturedPiece != null) capturedPiece.MoveTo(targetX, targetY);

        return !inCheck;
    }

    static MockPiece[][] DuplicateBoard(ChessGame game){
        MockPiece[][] duplicate = new MockPiece[8][8];
        for (ChessPiece piece : game.GetWhitePlayer().GetPieces()) {
            duplicate[piece.GetYPos()][piece.GetXPos()] = new MockPiece(piece);
        }
        for (ChessPiece piece : game.GetBlackPlayer().GetPieces()) {
            duplicate[piece.GetYPos()][piece.GetXPos()] = new MockPiece(piece);
        }
        return duplicate;
    }

    class MockPiece {
        public int xPos;
        public int yPos;
        public boolean isWhite;
        public int type;

        public MockPiece(ChessPiece chessPiece) {
            this.xPos = chessPiece.GetXPos();
            this.yPos = chessPiece.GetYPos();
            this.isWhite = chessPiece.GetIsWhite();
            switch (chessPiece.getClass().getSimpleName()) {
                case "Pawn":
                    this.type = 1;
                    break;
                case "Rook":
                    this.type = 2;
                    break;
                case "Knight":
                    this.type = 3;
                    break;
                case "Bishop":
                    this.type = 4;
                    break;
                case "Queen":
                    this.type = 5;
                    break;
                case "King":
                    this.type = 6;
                    break;
                default:
                    this.type = 0;
                    break;
            }
        }
    }


}
