package com.boardhub.chess.layoutsLogic;

import static com.boardhub.chess.dataClasses.ChessUI.darkNormal;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.boardhub.R;
import com.boardhub.chess.dataClasses.ChessGame;
import com.boardhub.chess.dataClasses.ChessPlayer;
import com.boardhub.chess.dataClasses.ChessUI;
import com.boardhub.chess.pieces.ChessPiece;

import java.util.HashMap;
import java.util.Set;

public class ChessGameFragment extends Fragment {
    private ChessPiece selectedPiece = null;
    private HashMap<int[], ChessPiece> activeMoves = new HashMap<>();

    private ImageButton[][] boardSquares = new ImageButton[8][8];
    private GridLayout chessGrid;

    private static final String ARG_PLAYER = "player";
    private ChessPlayer player;
    private ChessGame game;

    public ChessGameFragment() {
    }

    public static ChessGameFragment newInstance(ChessPlayer player) {
        ChessGameFragment fragment = new ChessGameFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PLAYER, player);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            player = (ChessPlayer) getArguments().getSerializable(ARG_PLAYER);
            game = player.GetGame();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.chess_game_fragment, container, false);
        setupBoard(root);
        LoadBoardPosition();
        return root;
    }

    private void setupBoard(View rootView) {
        chessGrid = rootView.findViewById(R.id.chess_grid);

        // Clear any existing views if this is called multiple times
        chessGrid.removeAllViews();

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                ImageButton square = new ImageButton(getContext());

                // 1. CRITICAL: Remove default Android button styling (shadows/internal padding)
                square.setBackground(null);
                square.setPadding(0, 0, 0, 0);
                square.setScaleType(ImageView.ScaleType.FIT_CENTER);

                // 2. Use GridLayout Weights to fill the 1:1 Square perfectly
                GridLayout.LayoutParams params = new GridLayout.LayoutParams();

                // width/height 0 tells the layout to use weights instead of fixed pixels
                params.width = 0;
                params.height = 0;

                // rowSpec(index, weight) - weight 1f ensures equal distribution
                params.rowSpec = GridLayout.spec(row, 1f);
                params.columnSpec = GridLayout.spec(col, 1f);

                // Ensure no accidental margins
                params.setMargins(0, 0, 0, 0);
                square.setLayoutParams(params);

                // 3. Coloring Logic
                if ((row + col) % 2 == 0) {
                    square.setBackgroundColor(ChessUI.lightNormal);
                } else {
                    square.setBackgroundColor(darkNormal);
                }

                // 4. Tagging and Click Listeners
                final int xPos = col;
                final int yPos = row;
                square.setTag(new int[]{row, col});
                square.setOnClickListener(v -> onSquareClicked(xPos, yPos));

                // 5. Add to UI and Reference Array
                chessGrid.addView(square);
                boardSquares[row][col] = square;
            }
        }
    }

    private void onSquareClicked(int x, int y){
        ChessPiece clickedPiece = game.GetPieceAt(x, y);
    }

    private void LoadBoardPosition(){
        for (ChessPiece[] row : player.GetGame().GetBoard()){
            for (ChessPiece piece : row){
                if (piece != null){
                    int xPos = piece.GetXPos();
                    int yPos = piece.GetYPos();
                    ImageButton square = boardSquares[yPos][xPos];
                    square.setImageResource(piece.GetImageResource());
                    System.out.println("Piece Placed");
                }
            }
        }
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                ImageButton square = boardSquares[row][col];

                if ((row + col) % 2 == 0) {
                    square.setBackgroundColor(ChessUI.lightNormal);
                } else {
                    square.setBackgroundColor(darkNormal);
                }

                ChessPiece p = player.GetGame().GetBoard()[row][col];
                if (p != null) {
                    square.setImageResource(p.GetImageResource());
                } else {
                    square.setImageResource(0);
                }
            }
        }
    }
}